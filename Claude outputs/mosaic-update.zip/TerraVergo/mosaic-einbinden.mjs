#!/usr/bin/env node
// MOSAiC – Ein Jahr im Eis: in den Bereich für Lehrkräfte einbinden
//
// Aufruf im Hauptordner des Erdlabors (TerraVergo):
//   node mosaic-einbinden.mjs
//
// Das Skript ist wiederholbar: Schon vorhandene Einträge werden übersprungen.
// 1. lehrkraefte/werkzeug/verschluesseln.mjs: Eintrag in APPS (Oberstufe, nach „Revier im Wandel“)
// 2. lehrkraefte/index.html: Eintrag in DIDAKTIK
// 3. lehrkraefte/lehrplan-niedersachsen.html, -bayern.html, -hamburg.html: je eine Tabellenzeile
// 4. Prüft, ob das Begleitheft in _lehrkraefte-originale/mosaic/ liegt
// 5. Startseite index.html: Karte in der Oberstufe (nur falls sie noch fehlt)
// Danach: node lehrkraefte/werkzeug/verschluesseln.mjs (fragt das Passwort ab) und diese Datei löschen.

import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const p = (...a) => path.join(ROOT, ...a);
if (!fs.existsSync(p('lehrkraefte', 'werkzeug', 'verschluesseln.mjs'))) {
  console.error('Bitte im Hauptordner des Erdlabors (TerraVergo) aufrufen.');
  process.exit(1);
}
const log = (s) => console.log(s);
function edit(rel, fn) {
  const f = p(...rel.split('/'));
  const alt = fs.readFileSync(f, 'utf8');
  const neu = fn(alt);
  if (neu === null) { log(`übersprungen (schon vorhanden): ${rel}`); return; }
  if (neu === alt) { console.error(`FEHLER: Einfügestelle nicht gefunden in ${rel}`); process.exitCode = 1; return; }
  fs.writeFileSync(f, neu);
  log(`aktualisiert: ${rel}`);
}
function nachZeile(text, marke, einfuegen) {
  const i = text.indexOf(marke);
  if (i < 0) return text;
  const ende = text.indexOf('\n', i);
  return text.slice(0, ende + 1) + einfuegen + '\n' + text.slice(ende + 1);
}

// 1. APPS
edit('lehrkraefte/werkzeug/verschluesseln.mjs', (t) => {
  if (/id:\s*'mosaic'/.test(t)) return null;
  return nachZeile(t, "{ id: 'mitteldeutscherevier'", "  { id: 'mosaic', titel: 'MOSAiC – Ein Jahr im Eis', stufe: 'Oberstufe', start: '' },");
});

// 2. DIDAKTIK
const DID = [
  'Wissenschaftsorientierung mit Originaldaten der MOSAiC-Expedition (PANGAEA, FAIR-Prinzipien, korrektes Zitieren) und Systemkompetenz (Mehren u. a., 2016; Rempfler & Uphues, 2010): Atmosphäre, Meereis, Ozean, Ökosystem und Biogeochemie der zentralen Arktis werden über einen vollständigen Jahresgang verknüpft; Eis-Albedo-Rückkopplung und die ausgleichende Rückkopplung des Eiswachstums, Urteil über die Reichweite eines einzigen Messjahres.',
  'Interaktiver Expeditionsglobus mit der gemessenen Drift (389 Tagespositionen) und Tageswetterdaten der Polarstern, 15 Stationen, Datenlabor mit Diagrammen, Streudiagramm und Driftrechner, Gruppenpuzzle zu fünf Forschungsfeldern mit Datenspuren, Wirkungsgefüge mit Musterlösung, Fakt oder Meinung und Quiz zu den MOSAiC-Datenregeln.'
];
edit('lehrkraefte/index.html', (t) => {
  if (t.includes("'mosaic': [")) return null;
  const i = t.indexOf("    'schanze': [");
  if (i < 0) return t;
  const ende = t.indexOf('\n', i);
  const zeile = t.slice(i, ende).replace(/\s+$/, '');
  const mitKomma = zeile.endsWith(',') ? zeile : zeile + ',';
  return t.slice(0, i) + mitKomma + '\n    \'mosaic\': ' + JSON.stringify(DID).replace(/"/g, "'").replace(/\\'/g, "\\'") + t.slice(ende);
});

// 3. Lehrplanseiten
const SP = {
  kp: 'Wissenschaftsorientierung (Originaldaten, FAIR-Regeln, Zitieren), Systemorientierung (Rückkopplungen), Aktualität, Kontroversität und Urteilsbildung, TTG (Gruppenpuzzle, Fakt oder Meinung)',
  um: 'Expeditionsglobus mit gemessener Drift und Tageswetterdaten (389 Tage), 15 Stationen, Datenlabor mit Streudiagramm und Driftrechner, fünf Forschungsfelder mit Datenspuren, Wirkungsgefüge mit Musterlösung',
  sa: 'Route beschreiben, Messreihen auswerten und kritisch prüfen, Polarnacht erklären, Erkenntnisse im Expertenvortrag belegen, Rückkopplungen verknüpfen, Messwert, Schlussfolgerung und Meinung unterscheiden'
};
const ZEILE = (jg, bezug) => `<tr data-g="o"><td><a href="../mosaic/"><b>MOSAiC – Ein Jahr im Eis</b></a> <span class="neu">neu</span></td><td>${jg}</td><td>${bezug}</td><td>${SP.kp}</td><td>${SP.um}</td><td>${SP.sa}</td></tr>`;
const LP = {
  'lehrkraefte/lehrplan-niedersachsen.html': ZEILE('Q (Basis 9/10)', 'FM 1 (Ursachen und Auswirkungen des Klimawandels); Anschluss KT 9 „Globale Herausforderungen des 21. Jahrhunderts“ (Klimawandel)'),
  'lehrkraefte/lehrplan-bayern.html': ZEILE('12 (Basis 10)', 'Geo 12 LB 2 (Treibhauseffekt, Vermeidung und Anpassung bewerten), LB 4 (Kippelemente, Klimarekonstruktion); Anschluss Geo 10 LB 4 (Folgen des Klimawandels)'),
  'lehrkraefte/lehrplan-hamburg.html': ZEILE('S', 'Studienstufe TB 1, Basismodul („Klimawandel – Klimakrise im Überblick“); 3.2 „Geosphären“ (Zusammenspiel aller Sphären)')
};
for (const [rel, zeile] of Object.entries(LP)) {
  edit(rel, (t) => (t.includes('href="../mosaic/"') ? null : nachZeile(t, 'href="../mitteldeutscherevier/"', zeile)));
}

// 5. Startseite: Karte in der Oberstufe (nur falls noch nicht vorhanden)
const KARTE = "        <a class=\"app\" href=\"mosaic/\">\n          <div class=\"pic\" style=\"background:#14254A\">\n            <svg viewBox=\"0 0 400 85\" preserveAspectRatio=\"xMidYMid slice\" aria-hidden=\"true\">\n              <rect width=\"400\" height=\"85\" fill=\"#14254A\"/>\n              <path d=\"M0 24Q90 2 190 18T400 10\" fill=\"none\" stroke=\"#5BE3A8\" stroke-width=\"9\" opacity=\".5\"/>\n              <path d=\"M0 36Q110 16 220 30T400 26\" fill=\"none\" stroke=\"#7FD4FF\" stroke-width=\"5\" opacity=\".45\"/>\n              <g fill=\"#fff\"><circle cx=\"40\" cy=\"10\" r=\"1.5\"/><circle cx=\"300\" cy=\"44\" r=\"1.3\"/><circle cx=\"370\" cy=\"40\" r=\"1.6\"/><circle cx=\"120\" cy=\"46\" r=\"1.2\"/></g>\n              <path d=\"M0 62Q100 56 200 62T400 60V85H0Z\" fill=\"#EAF4FB\" stroke=\"#1B1B2F\" stroke-width=\"2.2\"/>\n              <path d=\"M60 70l10 6-5 6M140 66l-6 8 7 5M300 70l8 5\" fill=\"none\" stroke=\"#7FA6C8\" stroke-width=\"1.6\"/>\n              <g transform=\"translate(282 61) scale(1.35)\" stroke=\"#1B1B2F\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n      <path d=\"M-12-1L-16-7H-11\" fill=\"none\" stroke=\"#E0393B\" stroke-width=\"1.8\"/>\n      <path d=\"M-13 0v-3.5h5V0Z\" fill=\"#2F6FD0\"/>\n      <path d=\"M-8-3l-.5-9h5L-3-3Z\" fill=\"#E0393B\"/><path d=\"M-8.4-12l-.2-3h5.2l-.1 3Z\" fill=\"#1E2F6E\"/>\n      <path d=\"M-3 0v-6h5v-4h7V0Z\" fill=\"#fff\"/><path d=\"M2-10h7v1.4H2Z\" fill=\"#E0393B\" stroke=\"none\"/><path d=\"M2.8-8h5.6v1.2H2.8Z\" fill=\"#1B1B2F\" stroke=\"none\"/>\n      <path d=\"M5-10v-6M3.5-14h3\" fill=\"none\" stroke=\"#fff\" stroke-width=\"1.6\"/>\n      <path d=\"M10 0v-5l5 2\" fill=\"none\" stroke=\"#E0393B\" stroke-width=\"1.8\"/>\n      <path d=\"M-17 0h34l3-2.5L16 7h-30l-2.5-4Z\" fill=\"#1E2F6E\"/>\n      <path d=\"M11 0h6l2.2-1.8-8.2.6Z\" fill=\"#2E8B57\" stroke=\"none\"/><path d=\"M-6 3h12v1.2H-6Z\" fill=\"#fff\" stroke=\"none\"/>\n    </g>\n              <path d=\"M150 76Q200 70 254 70\" fill=\"none\" stroke=\"#FFD23F\" stroke-width=\"2.5\" stroke-dasharray=\"5 5\"/>\n              <g transform=\"translate(18 50) rotate(-3)\"><rect width=\"128\" height=\"24\" rx=\"6\" fill=\"#E0393B\" stroke=\"#1B1B2F\" stroke-width=\"2.3\"/><text x=\"64\" y=\"18\" text-anchor=\"middle\" font-family=\"Bangers,Impact,sans-serif\" font-size=\"16\" fill=\"#fff\" letter-spacing=\".6\">389 TAGE IM EIS</text></g>\n            </svg>\n          </div>\n          <div class=\"body\">\n            <span class=\"tag\">Terra Vergo · Polarräume und Klima</span>\n            <h3 style=\"color:#1C7ED6;-webkit-text-stroke:1px #1B1B2F\">MOSAiC – Ein Jahr im Eis</h3>\n            <p><b style=\"color:#1B1B2F\">Was verrät ein Jahr im Eis über die Arktis im Klimawandel?</b> Die Drift der Polarstern mit Originaldaten auf dem Globus nachfahren, Messreihen auswerten und die Erkenntnisse der fünf Forschungsfelder zu einem Wirkungsgefüge verknüpfen.</p>\n            <span class=\"go\">Expedition starten →</span>\n          </div>\n        </a>\n";
edit('index.html', (t) => {
  if (t.includes('href="mosaic/"')) return null;
  const marke = '        <!-- Weitere Anwendungen für die Oberstufe:';
  const i = t.indexOf(marke);
  return i < 0 ? t : t.slice(0, i) + KARTE + t.slice(i);
});

// 4. Begleitheft
const bh = p('_lehrkraefte-originale', 'mosaic', 'begleitheft.html');
log(fs.existsSync(bh) ? 'Begleitheft gefunden: _lehrkraefte-originale/mosaic/begleitheft.html' : 'HINWEIS: Begleitheft fehlt in _lehrkraefte-originale/mosaic/');
log('\nNächster Schritt: node lehrkraefte/werkzeug/verschluesseln.mjs  (Passwort eingeben), danach diese Datei löschen.');
